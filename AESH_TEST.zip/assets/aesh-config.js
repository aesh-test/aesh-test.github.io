/* AESH TEST ONLY. Create a completely separate Supabase test project.
 * Do not paste a production key here. No private key should go to the browser.
 */
window.AESH_SUPABASE_CONFIG = Object.freeze({
  url: 'AESH_TEST_SUPABASE_URL',
  publishableKey: 'AESH_TEST_PUBLISHABLE_KEY'
});
