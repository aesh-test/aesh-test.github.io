/* AESH_TEST: Supabase intentionally isolated. No live user logins or database writes.
   For end-to-end testing, configure an entirely SEPARATE testing Supabase project. */
window.AESH_SUPABASE_CONFIG = Object.freeze({url:'',publishableKey:''});
